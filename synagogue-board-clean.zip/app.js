
const sb = getSupabase();

async function getSessionUser(){
  const { data, error } = await sb.auth.getUser();
  if(error) return null;
  return data.user || null;
}

async function getMyProfile(){
  const user = await getSessionUser();
  if(!user) return null;
  const { data, error } = await sb.from("profiles").select("*").eq("user_id", user.id).maybeSingle();
  if(error) throw error;
  return data;
}

async function requireLogin(){
  const user = await getSessionUser();
  if(!user){
    location.href = "login.html";
    throw new Error("Login required");
  }
  return user;
}

async function requireRole(roles){
  await requireLogin();
  const profile = await getMyProfile();
  if(!profile || !roles.includes(profile.role)){
    location.href = "login.html";
    throw new Error("Not authorized");
  }
  if(profile.status === "suspended"){
    await sb.auth.signOut();
    location.href = "login.html?suspended=1";
    throw new Error("Suspended");
  }
  return profile;
}

async function routeAfterLogin(){
  const profile = await getMyProfile();
  if(!profile) throw new Error("No profile was found for this account.");

  if(profile.status === "suspended"){
    await sb.auth.signOut();
    throw new Error("This account is suspended.");
  }

  if(profile.role === "master_admin"){
    location.href = "master-admin.html";
    return;
  }

  if(profile.status !== "approved"){
    throw new Error("Your account is still waiting for approval.");
  }

  if(profile.role === "synagogue_admin"){
    location.href = "admin.html";
    return;
  }

  location.href = "member.html";
}

function esc(v){
  return String(v ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

async function logout(){
  await sb.auth.signOut();
  location.href = "login.html";
}
