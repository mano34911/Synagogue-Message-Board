window.SUPABASE_URL = "https://chcfhxkggbrlxaopnfum.supabase.co";
window.SUPABASE_ANON_KEY = "sb_publishable_rwCYiLLLcYCOm7X9JXxAtQ_9ailfQ6D";

window.getSupabase = function(){
  if(!window.supabase) throw new Error("Supabase library did not load.");
  if(!window.__sb){
    window.__sb = window.supabase.createClient(
      window.SUPABASE_URL,
      window.SUPABASE_ANON_KEY
    );
  }
  return window.__sb;
};
