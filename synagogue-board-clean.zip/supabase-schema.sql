
-- CLEAN SYNAGOGUE BOARD SCHEMA
-- Supabase Auth + Database only.
-- Run this in a fresh Supabase project, or review carefully before running in an existing one.

create extension if not exists pgcrypto;

do $$ begin
  create type public.app_role as enum ('master_admin','synagogue_admin','member');
exception when duplicate_object then null;
end $$;

do $$ begin
  create type public.account_status as enum ('pending','approved','suspended');
exception when duplicate_object then null;
end $$;

create table if not exists public.synagogues (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null unique references auth.users(id) on delete cascade,
  name text not null,
  hebrew_name text,
  rabbi_name text,
  phone text,
  address_line1 text,
  city text,
  state_region text,
  postal_code text,
  country text default 'United States',
  slug text not null unique,
  status public.account_status not null default 'pending',

  board_title text,
  main_message text,
  shacharit text,
  mincha text,
  maariv text,
  candle_lighting text,
  parasha text,
  ticker_text text,

  trial_started_at timestamptz,
  subscription_status text not null default 'trial_pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  email text,
  full_name text,
  phone text,
  role public.app_role not null default 'member',
  status public.account_status not null default 'pending',
  synagogue_id uuid references public.synagogues(id) on delete cascade,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists profiles_synagogue_id_idx on public.profiles(synagogue_id);
create index if not exists profiles_role_idx on public.profiles(role);
create index if not exists synagogues_status_idx on public.synagogues(status);

create or replace function public.slugify(input text)
returns text
language sql
immutable
as $$
  select trim(both '-' from regexp_replace(lower(coalesce(input,'')), '[^a-z0-9]+', '-', 'g'));
$$;

create or replace function public.unique_synagogue_slug(base_name text)
returns text
language plpgsql
security definer
set search_path=public
as $$
declare
  base text;
  candidate text;
  n integer := 1;
begin
  base := public.slugify(base_name);
  if base = '' then base := 'synagogue'; end if;
  candidate := base;
  while exists(select 1 from public.synagogues where slug=candidate) loop
    n := n + 1;
    candidate := base || '-' || n::text;
  end loop;
  return candidate;
end;
$$;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
  meta jsonb := coalesce(new.raw_user_meta_data,'{}'::jsonb);
  reg_type text := coalesce(meta->>'registration_type','member');
  syn_id uuid;
  syn_name text;
begin
  if reg_type = 'synagogue' then
    syn_name := nullif(trim(meta->>'synagogue_name'),'');
    if syn_name is null then
      raise exception 'Synagogue name is required';
    end if;

    insert into public.synagogues(
      owner_user_id,name,rabbi_name,phone,address_line1,city,state_region,postal_code,country,slug,status
    ) values (
      new.id,
      syn_name,
      nullif(trim(meta->>'rabbi_name'),''),
      nullif(trim(meta->>'phone'),''),
      nullif(trim(meta->>'address_line1'),''),
      nullif(trim(meta->>'city'),''),
      nullif(trim(meta->>'state_region'),''),
      nullif(trim(meta->>'postal_code'),''),
      coalesce(nullif(trim(meta->>'country'),''),'United States'),
      public.unique_synagogue_slug(syn_name),
      'pending'
    )
    returning id into syn_id;

    insert into public.profiles(user_id,email,full_name,phone,role,status,synagogue_id)
    values (
      new.id,
      new.email,
      nullif(trim(meta->>'full_name'),''),
      nullif(trim(meta->>'phone'),''),
      'synagogue_admin',
      'pending',
      syn_id
    );

  else
    begin
      syn_id := nullif(meta->>'synagogue_id','')::uuid;
    exception when others then
      syn_id := null;
    end;

    if syn_id is null then
      raise exception 'Synagogue is required for member registration';
    end if;

    if not exists(select 1 from public.synagogues where id=syn_id and status='approved') then
      raise exception 'This synagogue is not available for member registration';
    end if;

    insert into public.profiles(user_id,email,full_name,phone,role,status,synagogue_id)
    values (
      new.id,
      new.email,
      nullif(trim(meta->>'full_name'),''),
      nullif(trim(meta->>'phone'),''),
      'member',
      'pending',
      syn_id
    );
  end if;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.is_master_admin()
returns boolean
language sql
stable
security definer
set search_path=public
as $$
  select exists(
    select 1 from public.profiles
    where user_id=auth.uid()
      and role='master_admin'
      and status='approved'
  );
$$;

create or replace function public.my_synagogue_id()
returns uuid
language sql
stable
security definer
set search_path=public
as $$
  select synagogue_id from public.profiles where user_id=auth.uid() limit 1;
$$;

alter table public.synagogues enable row level security;
alter table public.profiles enable row level security;

drop policy if exists "public read approved synagogues" on public.synagogues;
create policy "public read approved synagogues"
on public.synagogues for select
using (
  status='approved'
  or owner_user_id=auth.uid()
  or public.is_master_admin()
);

drop policy if exists "master updates synagogues" on public.synagogues;
create policy "master updates synagogues"
on public.synagogues for update
using (public.is_master_admin())
with check (public.is_master_admin());

drop policy if exists "synagogue admin updates own synagogue" on public.synagogues;
create policy "synagogue admin updates own synagogue"
on public.synagogues for update
using (
  id=public.my_synagogue_id()
  and exists(
    select 1 from public.profiles
    where user_id=auth.uid()
      and role='synagogue_admin'
      and status='approved'
  )
)
with check (
  id=public.my_synagogue_id()
  and owner_user_id=auth.uid()
);

drop policy if exists "users read own profile" on public.profiles;
create policy "users read own profile"
on public.profiles for select
using (
  user_id=auth.uid()
  or public.is_master_admin()
  or (
    synagogue_id=public.my_synagogue_id()
    and exists(
      select 1 from public.profiles p
      where p.user_id=auth.uid()
        and p.role='synagogue_admin'
        and p.status='approved'
    )
  )
);

drop policy if exists "master updates profiles" on public.profiles;
create policy "master updates profiles"
on public.profiles for update
using (public.is_master_admin())
with check (public.is_master_admin());

drop policy if exists "synagogue admin updates member profiles" on public.profiles;
create policy "synagogue admin updates member profiles"
on public.profiles for update
using (
  synagogue_id=public.my_synagogue_id()
  and role='member'
  and exists(
    select 1 from public.profiles p
    where p.user_id=auth.uid()
      and p.role='synagogue_admin'
      and p.status='approved'
  )
)
with check (
  synagogue_id=public.my_synagogue_id()
  and role='member'
);

-- Automatically start the 7-day trial when Master Admin approves a synagogue.
create or replace function public.start_trial_on_approval()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  if old.status is distinct from new.status and new.status='approved' then
    if new.trial_started_at is null then
      new.trial_started_at := now();
      new.subscription_status := 'trial';
    end if;
  end if;
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists before_synagogue_update on public.synagogues;
create trigger before_synagogue_update
before update on public.synagogues
for each row execute function public.start_trial_on_approval();

-- =========================================================
-- MASTER ADMIN BOOTSTRAP
-- =========================================================
-- 1. Register a normal account first.
-- 2. Then run the following with that account's email:
--
-- update public.profiles
-- set role='master_admin', status='approved'
-- where email='YOUR_EMAIL@example.com';
--
-- After that, log out and log back in.
