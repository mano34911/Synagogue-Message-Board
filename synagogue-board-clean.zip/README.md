# Synagogue Board Clean Rebuild

This is a clean rebuild using **Supabase Auth + Supabase Database only**.

## Pages

- `index.html` — public synagogue message board
- `register.html` — new synagogue owner registration
- `member-register.html` — member registration for an approved synagogue
- `login.html` — one login page for all users
- `admin.html` — synagogue admin dashboard
- `master-admin.html` — master admin dashboard
- `member.html` — approved member landing page

## Roles

- `master_admin`
- `synagogue_admin`
- `member`

## Statuses

- `pending`
- `approved`
- `suspended`

## Setup order

1. Create a Supabase project, or use the existing project.
2. Open Supabase SQL Editor and run `supabase-schema.sql`.
3. Edit `supabase-config.js` with the project URL and publishable anon key.
4. Register the first owner with `register.html`.
5. Bootstrap your master-admin account with the SQL shown at the bottom of `supabase-schema.sql`.
6. Approve the synagogue in `master-admin.html`.
7. Members can then use `member-register.html`.
8. Enable GitHub Pages on the repository.

The code intentionally does **not** use Firebase authentication.
